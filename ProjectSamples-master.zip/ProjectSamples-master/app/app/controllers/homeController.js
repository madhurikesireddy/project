/**
 * Created by kiran on 4/25/2015.
 */
app.controller('homeController',[
    '$scope',function($scope){
        $scope.data = "Hello I am referred from the home controller";
    }
]);